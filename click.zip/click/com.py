import os
import sys
import subprocess, signal
import time
f = open("c:\click\urllist")
#print f.read()
for line in f:
	line=line.strip()
	os.system('firefox "'+line+'"  &')
	time.sleep(10)
os.system("taskkill /im /f firefox.exe")
'''
		self._logger.debug( 'Firefox cleanup - FAILURE!' )
	else:
		self._logger.debug( 'Firefox cleanup - SUCCESS!' )
'''
